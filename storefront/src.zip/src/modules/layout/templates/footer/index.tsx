import { Text, clx } from "@medusajs/ui"
import { getCollectionsList } from "@lib/data/collections"
import LocalizedClientLink from "@modules/common/components/localized-client-link"
import Image from "next/image"
import { Leaf, Recycle, Award, Mail, Phone, MapPin } from "lucide-react"

export default async function Footer() {
  // Remove the problematic getCategoriesList call and just use static content
  let collections = []
  try {
    const collectionsData = await getCollectionsList(0, 6)
    collections = collectionsData?.collections || []
  } catch (error) {
    // If collections fail to load, continue with empty array
    console.log("Collections not available:", error)
  }

  return (
    <footer className="border-t border-ui-border-base w-full bg-gray-900 text-white">
      <div className="content-container flex flex-col w-full">
        {/* Main Footer Content */}
        <div className="flex flex-col gap-y-8 pt-16 pb-8">
          <div className="flex flex-col md:flex-row items-start justify-between gap-8">
            {/* Brand Section */}
            <div className="flex flex-col gap-y-4 max-w-sm">
              <LocalizedClientLink
                href="/"
                className="txt-compact-xlarge-plus text-ui-fg-subtle hover:text-ui-fg-base uppercase"
              >
                <Image
                  src="/spearink-logo.png"
                  alt="Spearink - Think Green"
                  width={200}
                  height={60}
                  className="h-12 w-auto brightness-0 invert"
                />
              </LocalizedClientLink>
              <Text className="text-gray-300 leading-relaxed">
                Leading the sustainable printing revolution with premium refilled cartridges. 
                Same quality, lower cost, better for the planet.
              </Text>
              
              {/* Environmental Stats */}
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="text-center">
                  <div className="text-[#48a701] font-bold text-lg">2.5M+</div>
                  <div className="text-xs text-gray-400">Recycled</div>
                </div>
                <div className="text-center">
                  <div className="text-[#48a701] font-bold text-lg">80%</div>
                  <div className="text-xs text-gray-400">Less CO₂</div>
                </div>
                <div className="text-center">
                  <div className="text-[#48a701] font-bold text-lg">50%</div>
                  <div className="text-xs text-gray-400">Savings</div>
                </div>
              </div>
            </div>

            {/* Navigation Links */}
            <div className="flex flex-col md:flex-row gap-8 md:gap-16">
              {/* Products */}
              <div className="flex flex-col gap-y-2">
                <span className="txt-small-plus txt-ui-fg-base font-semibold text-white">
                  Products
                </span>
                <ul className="grid grid-cols-1 gap-2">
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/store"
                    >
                      All Products
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/store?category=ink-cartridges"
                    >
                      Ink Cartridges
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/store?category=toner-cartridges"
                    >
                      Toner Cartridges
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/store?category=original-cartridges"
                    >
                      Original Cartridges
                    </LocalizedClientLink>
                  </li>
                </ul>
              </div>

              {/* Services */}
              <div className="flex flex-col gap-y-2">
                <span className="txt-small-plus txt-ui-fg-base font-semibold text-white">
                  Services
                </span>
                <ul className="grid grid-cols-1 gap-2">
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/recycling"
                    >
                      Cartridge Recycling
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/services/refilling"
                    >
                      Refilling Service
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/services/pickup"
                    >
                      Pickup Service
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/services/corporate"
                    >
                      Corporate Solutions
                    </LocalizedClientLink>
                  </li>
                </ul>
              </div>

              {/* Company */}
              <div className="flex flex-col gap-y-2">
                <span className="txt-small-plus txt-ui-fg-base font-semibold text-white">
                  Company
                </span>
                <ul className="grid grid-cols-1 gap-2">
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/about"
                    >
                      About Us
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/sustainability"
                    >
                      Sustainability
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/franchise"
                    >
                      Franchise
                    </LocalizedClientLink>
                  </li>
                  <li>
                    <LocalizedClientLink
                      className="txt-small text-gray-300 hover:text-[#48a701] transition-colors"
                      href="/contact"
                    >
                      Contact
                    </LocalizedClientLink>
                  </li>
                </ul>
              </div>

              {/* Contact Info */}
              <div className="flex flex-col gap-y-2">
                <span className="txt-small-plus txt-ui-fg-base font-semibold text-white">
                  Contact
                </span>
                <ul className="grid grid-cols-1 gap-2">
                  <li className="flex items-center gap-2 text-gray-300">
                    <Phone className="h-4 w-4" />
                    <span className="txt-small">1-800-SPEARINK</span>
                  </li>
                  <li className="flex items-center gap-2 text-gray-300">
                    <Mail className="h-4 w-4" />
                    <span className="txt-small">info@spearink.com</span>
                  </li>
                  <li className="flex items-center gap-2 text-gray-300">
                    <MapPin className="h-4 w-4" />
                    <LocalizedClientLink
                      href="/locations"
                      className="txt-small hover:text-[#48a701] transition-colors"
                    >
                      Find Store Locations
                    </LocalizedClientLink>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Environmental Commitment Section */}
          <div className="border-t border-gray-700 pt-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Leaf className="h-5 w-5 text-[#48a701]" />
                  <span className="text-sm text-gray-300">Carbon Neutral</span>
                </div>
                <div className="flex items-center gap-2">
                  <Recycle className="h-5 w-5 text-[#48a701]" />
                  <span className="text-sm text-gray-300">100% Recyclable</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-[#48a701]" />
                  <span className="text-sm text-gray-300">ISO Certified</span>
                </div>
              </div>
              
              <div className="text-sm text-gray-300">
                <span className="text-[#48a701] font-semibold">Think Green</span> - Every cartridge makes a difference
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="flex w-full mb-16 justify-between text-gray-400 border-t border-gray-700 pt-8">
          <Text className="txt-compact-small">
            © {new Date().getFullYear()} Spearink. All rights reserved.
          </Text>
          <div className="flex gap-4">
            <LocalizedClientLink
              href="/privacy"
              className="txt-compact-small hover:text-[#48a701] transition-colors"
            >
              Privacy Policy
            </LocalizedClientLink>
            <LocalizedClientLink
              href="/terms"
              className="txt-compact-small hover:text-[#48a701] transition-colors"
            >
              Terms of Service
            </LocalizedClientLink>
          </div>
        </div>
      </div>
    </footer>
  )
}

