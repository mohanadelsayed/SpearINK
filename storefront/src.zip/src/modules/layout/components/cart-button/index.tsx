import { LineItem, Region } from "@medusajs/types"
import { enrichLineItems, retrieveCart } from "@lib/data/cart"
import { getCustomer } from "@lib/data/customer"
import LocalizedClientLink from "@modules/common/components/localized-client-link"
import { ShoppingCart } from "lucide-react"

const fetchCart = async () => {
  const cart = await retrieveCart()

  if (!cart) {
    return null
  }

  if (cart?.items?.length) {
    const enrichedItems = await enrichLineItems(cart?.items, cart?.region_id)
    cart.items = enrichedItems as LineItem[]
  }

  return cart
}

export default async function CartButton() {
  const cart = await fetchCart()
  const customer = await getCustomer()

  return (
    <LocalizedClientLink
      className="hover:text-[#48a701] transition-colors flex items-center gap-2 bg-[#48a701] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#48a701]/90"
      href="/cart"
      data-testid="nav-cart-link"
    >
      <ShoppingCart className="h-4 w-4" />
      <span>Cart ({cart?.items?.length || 0})</span>
    </LocalizedClientLink>
  )
}

