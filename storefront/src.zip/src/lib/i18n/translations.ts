export type Language = 'en' | 'ar'

export interface Translations {
  // Navigation
  nav: {
    products: string
    recycling: string
    sustainability: string
    franchise: string
    search: string
    account: string
    cart: string
  }
  // Hero Section
  hero: {
    title: string
    subtitle: string
    description: string
    shopNow: string
    learnMore: string
    recycleNow: string
  }
  // Sustainability Section
  sustainability: {
    title: string
    subtitle: string
    description: string
    stats: {
      cartridgesRecycled: string
      co2Reduced: string
      costSavings: string
    }
    learnMore: string
  }
  // Recycling Program
  recycling: {
    title: string
    subtitle: string
    description: string
    vouchers: {
      ink: string
      toner: string
    }
    howItWorks: string
    startRecycling: string
  }
  // Franchise
  franchise: {
    title: string
    subtitle: string
    description: string
    investment: string
    revenue: string
    learnMore: string
  }
  // Footer
  footer: {
    company: string
    products: string
    services: string
    support: string
    contact: string
    phone: string
    email: string
    address: string
    thinkGreen: string
    tagline: string
    allRights: string
  }
  // Common
  common: {
    loading: string
    error: string
    tryAgain: string
    close: string
    open: string
    menu: string
  }
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      products: "Products",
      recycling: "Recycling",
      sustainability: "Sustainability", 
      franchise: "Franchise",
      search: "Search",
      account: "Account",
      cart: "Cart"
    },
    hero: {
      title: "Premium Refilled Cartridges",
      subtitle: "Think Green, Save More",
      description: "High-quality refilled ink and toner cartridges that deliver exceptional results while reducing environmental impact. Save up to 50% compared to original cartridges.",
      shopNow: "Shop Now",
      learnMore: "Learn More",
      recycleNow: "Recycle Now"
    },
    sustainability: {
      title: "Environmental Impact",
      subtitle: "Making a Difference Together",
      description: "Every refilled cartridge helps reduce waste and carbon footprint. Join our mission to create a more sustainable future.",
      stats: {
        cartridgesRecycled: "Cartridges Recycled",
        co2Reduced: "Less CO₂",
        costSavings: "Savings"
      },
      learnMore: "Learn More"
    },
    recycling: {
      title: "Cartridge Recycling Program",
      subtitle: "Turn Your Empty Cartridges Into Rewards",
      description: "Bring your empty cartridges and receive valuable vouchers for your next purchase. Help the environment while saving money.",
      vouchers: {
        ink: "$5 for Ink Cartridges",
        toner: "$8 for Toner Cartridges"
      },
      howItWorks: "How It Works",
      startRecycling: "Start Recycling"
    },
    franchise: {
      title: "Franchise Opportunities",
      subtitle: "Join the Green Revolution",
      description: "Start your own sustainable printing business with our proven franchise model. Complete support and training included.",
      investment: "Total Investment: $180K",
      revenue: "Annual Revenue: $300K-$500K",
      learnMore: "Learn More"
    },
    footer: {
      company: "Company",
      products: "Products",
      services: "Services", 
      support: "Support",
      contact: "Contact Us",
      phone: "+1 (555) 123-4567",
      email: "info@spearink.com",
      address: "123 Green Street, Eco City, EC 12345",
      thinkGreen: "Think Green",
      tagline: "Every cartridge makes a difference",
      allRights: "All rights reserved"
    },
    common: {
      loading: "Loading...",
      error: "Error occurred",
      tryAgain: "Try Again",
      close: "Close",
      open: "Open",
      menu: "Menu"
    }
  },
  ar: {
    nav: {
      products: "المنتجات",
      recycling: "إعادة التدوير",
      sustainability: "الاستدامة",
      franchise: "الامتياز التجاري",
      search: "البحث",
      account: "الحساب",
      cart: "السلة"
    },
    hero: {
      title: "خراطيش معبأة عالية الجودة",
      subtitle: "فكر أخضر، وفر أكثر",
      description: "خراطيش حبر وتونر معبأة عالية الجودة تقدم نتائج استثنائية مع تقليل التأثير البيئي. وفر حتى 50% مقارنة بالخراطيش الأصلية.",
      shopNow: "تسوق الآن",
      learnMore: "اعرف المزيد",
      recycleNow: "أعد التدوير الآن"
    },
    sustainability: {
      title: "التأثير البيئي",
      subtitle: "نصنع الفرق معاً",
      description: "كل خرطوشة معبأة تساعد في تقليل النفايات والبصمة الكربونية. انضم إلى مهمتنا لخلق مستقبل أكثر استدامة.",
      stats: {
        cartridgesRecycled: "خرطوشة معاد تدويرها",
        co2Reduced: "أقل من ثاني أكسيد الكربون",
        costSavings: "توفير"
      },
      learnMore: "اعرف المزيد"
    },
    recycling: {
      title: "برنامج إعادة تدوير الخراطيش",
      subtitle: "حول خراطيشك الفارغة إلى مكافآت",
      description: "أحضر خراطيشك الفارغة واحصل على قسائم قيمة لشرائك التالي. ساعد البيئة واوفر المال.",
      vouchers: {
        ink: "5 دولار لخراطيش الحبر",
        toner: "8 دولار لخراطيش التونر"
      },
      howItWorks: "كيف يعمل",
      startRecycling: "ابدأ إعادة التدوير"
    },
    franchise: {
      title: "فرص الامتياز التجاري",
      subtitle: "انضم إلى الثورة الخضراء",
      description: "ابدأ عملك الخاص في الطباعة المستدامة مع نموذج الامتياز المجرب. دعم وتدريب كامل متضمن.",
      investment: "إجمالي الاستثمار: 180 ألف دولار",
      revenue: "الإيرادات السنوية: 300-500 ألف دولار",
      learnMore: "اعرف المزيد"
    },
    footer: {
      company: "الشركة",
      products: "المنتجات",
      services: "الخدمات",
      support: "الدعم",
      contact: "اتصل بنا",
      phone: "+966 11 123 4567",
      email: "info@spearink.com",
      address: "123 شارع الأخضر، المدينة البيئية، الرياض 12345",
      thinkGreen: "فكر أخضر",
      tagline: "كل خرطوشة تصنع الفرق",
      allRights: "جميع الحقوق محفوظة"
    },
    common: {
      loading: "جاري التحميل...",
      error: "حدث خطأ",
      tryAgain: "حاول مرة أخرى",
      close: "إغلاق",
      open: "فتح",
      menu: "القائمة"
    }
  }
}

